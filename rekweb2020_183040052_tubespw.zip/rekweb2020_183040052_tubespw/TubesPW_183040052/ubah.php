<?php 
session_start();
if (!isset($_SESSION['username'])) {
	header("Location: login.php");
	exit;
}
require 'functions.php';

$no = $_GET['no'];
$f = query("SELECT * FROM film WHERE no = $no")[0];

if (isset($_POST['ubah'])){
	if (ubah($_POST) > 0) {
		echo "<script>
				alert('data berhasil diubah!');
				document.location.href = 'admin.php';
				</script>";
	} else {
		echo "<script>
				alert('data gagal diubah!');
				document.location.href = 'admin.php';
				</script>";
	}

}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Form Ubah Data Mahasiswa</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- <style>
		
	</style> -->

	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="assets/css/ubah.css">
</head>
<body background="assets/img/mg2.jpg">
	<div class="container">
		<h3 align="center" style="padding-bottom:20px;padding-top:20px;text-shadow:0 0 20px #d8d8d8 ">Ubah Data Mahasiswa</h3>
		<form method="post" action="" enctype="multipart/form-data">
			<input type="hidden" name="no" value="<?= $f['no']; ?>">
			<input type="hidden" name="gambarLama" value="<?= $f['poster']; ?>">
			<ul class="add">
				<li>
					Judul Film :
					<input class="form-control form-control-sm col-11" type="text" placeholder="Judul Film" name="judul" value="<?= $f['judul']; ?>" required>
				</li>
				<li>
					Tahun Rilis :
					<input class="form-control form-control-sm col-11" type="text" placeholder="Tahun Rilis" name="tahun" value="<?= $f['tahun']; ?>" required>
				</li>
				<li>
					Distributor Film : 
					<input class="form-control form-control-sm col-11" type="text" placeholder="Distributor Film" name="distribusi" value="<?= $f['distribusi']; ?>" required>
				</li>
				<li>
					Durasi Film : 
					<input class="form-control form-control-sm col-11" type="text" placeholder="Durasi Film" name="durasi" value="<?= $f['durasi']; ?>" required>
				</li>
				<li>
					Sinopsis Film : 
					<input class="form-control form-control-sm col-11" type="text" placeholder="Sinopsis Film" name="sinopsis" value="<?= $f['sinopsis']; ?>" required>
				</li>
				<li>
					Poster Film :
    				<input type="file" class="form-control-file" id="exampleFormControlFile1" name="poster"><br>
    				<img class="im" src="assets/img/<?= $f['poster']; ?>" alt="Poster"> 
				</li>
				<li class="tmb">
					<button class="btn btn-success" type="submit" name="ubah">Ubah Data</button>
					<a class="btn btn-danger"href="admin.php" role="button">Kembali</a>
				</li>
			</ul>
		</form>
	</div>

	<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>