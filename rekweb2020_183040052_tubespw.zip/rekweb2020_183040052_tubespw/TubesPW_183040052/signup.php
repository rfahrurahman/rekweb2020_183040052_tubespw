<?php 
require 'functions.php';

if (isset($_POST['registrasi'])) {
	if (registrasi($_POST) > 0) {
		echo "<script>
				alert('registrasi berhasil!')
				document.location.href= 'login.php';
			</script>";
	} else {
		echo mysqli_error($conn);
	}
}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Sign Up Page</title>
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="assets/css/signup.css">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body background="assets/img/signup.jpg" style="background-size:auto;background-repeat:no-repeat;">
 <div class="container">
        <div class="card card-container">
            <h1 style="color:white;font-size:30px;text-align: center;padding-bottom:30px;">Create an Account</h1>
                <form class="form-signin" method="post">
                <input type="text" id="inputUser" class="form-control" placeholder="Username" name="username" required autofocus>
                <input type="password" id="inputPassword" class="form-control" placeholder="Choose a Password" name="password1" required>
                <input type="password" id="inputPassword" class="form-control" placeholder="Confirm Password" name="password2" required>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit" name="registrasi">Sign Up</button>
                <p align="center" style="padding-top: 20px;">OR</p>
               	<a href="login.php" style="padding-left:115px;">Back?</a>
            </form>
        </div>
    </div>
</body>
</html>
