let keyword = document.getElementById('keyword');
let container = document.getElementById('container');

	keyword.addEventListener('keyup', function() {
		
		// ajax
		let xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function () {
			if (xhr.readyState == 4 && xhr.status == 200) {
				container.innerHTML = xhr.responseText;
			}
		}
		xhr.open('get', 'cari_index.php?keyword=' + keyword.value);
		xhr.send();
	});