<?php 
require 'functions.php';

$keyword = $_GET['keyword'];
$query_cari = "SELECT * FROM film WHERE
				judul LIKE '%$keyword%'
				";
$film = query($query_cari);
 ?>

 		<table cellpadding="5" cellspacing="0" class="table table-bordered table-hover bg-light">
		<tr class="bg-light">
			<th>No.</th>
			<th>Opsi</th>
			<th class="ft">Poster Film</th>
			<th>Judul Film</th>
			<th class="th">Tahun Rilis</th>
			<th>Distributor Film</th>
			<th>Durasi Film</th>
			<th class="sino1">Sinopsis Film</th>
		</tr>
		<?php if (empty($film)) :	?>
			<tr>
				<td colspan="6" align="center">Data tidak ditiemukan</td>
			</tr>
		<?php endif; ?>

		<?php 
		$i = 1;
		foreach ($film as $f) : 
		?>
		<tr>
			<td><?= $i++; ?></td>
			<td>
				<a class="btn btn-success" href="ubah.php?no=<?=$f['no']; ?>" role="button">Ubah</a>
				<a class="btn btn-danger" href="hapus.php?no=<?=$f['no']; ?>" onclick="return confirm('yakin anda ingin menghapusnya?');" role="button">Hapus</a>
			</td>
			<td class="img ft"><img src="assets/img/<?= $f['poster'] ?>" alt="poster"></td>
			<td><?= $f['judul']; ?></td>
			<td class="th"><?= $f['tahun'] ?></td>
			<td><?= $f['distribusi']; ?></td>
			<td><?= $f['durasi']; ?></td>
			<td class="sino2"><?= $f['sinopsis']; ?></td>
		</tr>
	<?php endforeach; ?>
	</table>