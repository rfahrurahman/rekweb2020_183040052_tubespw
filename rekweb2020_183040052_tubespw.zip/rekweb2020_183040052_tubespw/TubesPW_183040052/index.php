<?php
session_start();
if (isset($_SESSION['username'])) {
  header("Location: login.php");
  exit;
} 
require 'functions.php';

$film = query("SELECT * FROM film");



 ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <link rel="shortcut icon" href="assets/img/download.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <!-- My CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/index.css">

    <title>Welcome To My Website</title>
  </head>
  <body style="background-image:url('assets/img/mg2.jpg');">
    <!-- navbar -->
<nav class="navbar fixed-bottom navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand ces" href="#">
     <img src="assets/img/download.png" width="40" height="30" class="d-inline-block align-top" alt="">
    CesarWeb
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="keyword" id="keyword">
          <button class="btn btn-outline-light my-2 my-sm-0 p-0 invisible" type="submit" name="cari" id="tombol"></button> 
    </form>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">   

  </div>
   <a class="btn btn-primary" href="login.php" role="button">Sign In As Admin</a>
</nav>

    <h1 align="center" style="margin-top:30px;">Film Terfavorit Abad Ke-20</h1>
  <div class="container" id="container">
    <?php foreach ($film as $f) : ?>
    <div class="card kartu" style="width: 25rem;">
      <div class="gm" style="background-image: url(assets/img/hh.jpeg);background-size:auto;">
      <img src="assets/img/<?= $f['poster']; ?>" class="card-img-top" alt="...">
      </div>
      <div class="card-body">
        <h5 class="card-title" align="center"><?= $f['judul']; ?> (<?= $f['tahun']; ?>)</h5>
        <a href="detail.php?no=<?= $f['no']; ?>" class="btn btn-primary tb">Go Detail</a>
      </div>
    </div>

    <?php endforeach ?>
  </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script type="text/javascript" src="assets/js/script1.js"></script>
  </body>
</html>