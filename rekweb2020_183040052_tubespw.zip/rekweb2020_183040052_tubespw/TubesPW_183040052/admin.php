<?php 
session_start();
if (!isset($_SESSION['username'])) {
	header("Location: login.php");
	exit;
}
require 'functions.php';

$film = query("SELECT * FROM film");

if(isset($_GET['cari'])){
	$keyword = $_GET['keyword'];
	$query_cari = "SELECT * FROM film WHERE
					judul LIKE '%$keyword%'
					";
	$film = query($query_cari);
}

if (isset($_POST['tambah'])){
	if (tambah($_POST) > 0) {
		echo "<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'admin.php';
				</script>";
	} else {
		echo "<script>
				alert('data gagal ditambahkan!');
				document.location.href = 'admin.php';
				</script>";
	}

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="shortcut icon" href="assets/img/download.png">
	<meta charset="UTF-8">
	<title>Data Film</title>

	<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

	<!-- My CSS -->
	<link rel="stylesheet" type="text/css" href="assets/css/admin.css">
</head>
<body style="background-image:url('assets/img/mg2.jpg');background-size:cover;background-repeat: no-repeat;background-position:fixed;">
<!-- navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand ces" href="#">
  	 <img src="assets/img/download.png" width="40" height="30" class="d-inline-block align-top" alt="">
    CesarWeb
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
	<form class="form-inline my-2 my-lg-0">
      		<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="keyword" id="keyword">
       		<button class="btn btn-outline-light my-2 my-sm-0 p-0 invisible" type="submit" name="cari" id="tombol"></button> 
    </form>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
	    <li class="nav-item active">
	    	<a class="nav-link" href="admin.php">Home <span class="sr-only">(current)</span></a>
	    </li>
	    <li class="nav-item active">
	    	<a class="nav-link" href="tambah.php" data-toggle="modal" data-target="#add">Add Data</a>
	    </li>
	    <li>
	    	
	    </li>
    </ul>
   

	<a class="btn btn-danger" href="logout.php" role="button">Logout!</a>
  </div>
</nav>

<!-- Modal Add Data -->
<div class="modal fade" id="add" tabindex="-1" role="dialog" aria-labelledby="add_data" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="add_data">Tambah Data Film</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form method="post" action="" enctype="multipart/form-data">
			<ul class="add">
				<li>
					Judul Film :
					<input class="form-control form-control-sm col-10" type="text" placeholder="Judul Film" name="judul" required>
				</li>
				<li>
					Tahun Rilis :
					<select class="form-control form-control-sm col-10" name="tahun">
				      <?php for ($i = 19; $i >= 10 ; $i--) : ?>
				      	<option>20<?= $i ?></option>
				      <?php endfor ?>
				      <?php for ($i = 9; $i >= 0 ; $i--) : ?>
				      	<option>200<?= $i ?></option>
				      <?php endfor ?>
				    </select>
				</li>
				<li>
					Distributor Film : 
					<input class="form-control form-control-sm col-10" type="text" placeholder="Distributor Film" name="distribusi" required>
				</li>
				<li>
					Durasi Film : 
					<input class="form-control form-control-sm col-10" type="text" placeholder="Durasi Film" name="durasi" required>
				</li>
				<li>
					Sinopsis Film : 
					<textarea class="form-control col-10" name="sinopsis" rows="5" required></textarea>
				</li>
				<li>
					Poster Film : 
    				<input type="file" class="form-control-file" id="exampleFormControlFile1" name="poster">
				</li>
				<li>
					<button class="btn btn-success" type="submit" name="tambah">Kirim</button>
				</li>
			</ul>
		</form>
      </div>
    </div>
  </div>
</div>

	<h1 class="jud">Film Terfavorit Abad Ke-20</h1>
<div id="container">
	<table cellpadding="5" cellspacing="0" class="table table-bordered table-hover bg-light">
		<tr class="bg-light thead-dark">
			<th>No.</th>
			<th>Opsi</th>
			<th class="ft">Poster Film</th>
			<th>Judul Film</th>
			<th class="th">Tahun Rilis</th>
			<th>Distributor Film</th>
			<th>Durasi Film</th>
			<th class="sino1">Sinopsis Film</th>
		</tr>
		<?php if (empty($film)) : ?>
			<tr>
				<td colspan="6" align="center">Data tidak ditiemukan</td>
			</tr>
		<?php endif; ?>

		<?php 
		$i = 1;
		foreach ($film as $f) : 
		?>
		<tr>
			<td><?= $i++; ?></td>
			<td>
				<a class="btn btn-success" href="ubah.php?no=<?=$f['no']; ?>" role="button">Ubah</a>
				<a class="btn btn-danger" href="hapus.php?no=<?=$f['no']; ?>" onclick="return confirm('yakin anda ingin menghapusnya?');" role="button">Hapus</a>
			</td>
			<td class="img ft"><img src="assets/img/<?= $f['poster'] ?>" alt="poster"></td>
			<td><?= $f['judul']; ?></td>
			<td class="th"><?= $f['tahun'] ?></td>
			<td><?= $f['distribusi']; ?></td>
			<td><?= $f['durasi']; ?></td>
			<td class="sino2"><?= $f['sinopsis']; ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
</div>

	 <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script type="text/javascript" src="assets/js/script.js"></script>
</body>
</html>