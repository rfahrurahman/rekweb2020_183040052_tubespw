<?php 
require 'functions.php';
session_start();
if (isset($_SESSION['username'])) {
	header("Location: admin.php");
	exit;
}
	if(isset($_POST['login'])){
		$username = $_POST['username'];
		$password = $_POST['password'];

		$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");

		if (mysqli_num_rows($cek_user) > 0) {
			//$_SESSION['username'] = $username;
			//header("Location: index.php");
			//exit;
			$user = mysqli_fetch_assoc($cek_user);
			if (password_verify($password, $user['password'])) {
				// ok, boleh login
				$_SESSION['username'] = $username;
				header("Location: admin.php");
			} else {
				//gagal, password salah
				$error = 'Username/Password Salah!';
				$error1 = 'warning';
			}	
		} else {
			$error = 'Username/Password Salah!';
			$error1 = 'warning';
		}
	}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login Page</title>
    <!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<!--Custom styles-->
	<link rel="stylesheet" type="text/css" href="assets/css/login.css">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body background="assets/img/login.jpg" style="background-size: auto;
	background-repeat: no-repeat;">
	 <?php if (isset($error)) : ?>
		<script>
				swal("<?= $error ?>", "", "<?= $error1 ?>");
		</script>
	<?php endif ?>
 <div class="container">
        <div class="card card-container">
            <img id="profile-img" class="profile-img-card" src="assets/img/avatar.jpg">
            <p id="profile-name" class="profile-name-card"></p>
            <form class="form-signin" method="post">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="text" id="inputEmail" class="form-control" placeholder="Username" name="username" required autofocus>
                <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required>
                <div id="remember" class="checkbox">
                    <label>
                        <input type="checkbox" value="remember-me"> Remember me
                    </label>
                </div>
                <button class="btn btn-lg btn-primary btn-block btn-signin" onclick="popup()" type="submit" name="login">Sign in</button>
                
            </form>
            Don't have an account?<a href="signup.php">Sign Up</a>
            <a href="index.php">Back?</a>
        </div>         
    </div>
</body>
</html>
