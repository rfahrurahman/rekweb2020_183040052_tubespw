<?php 
require 'functions.php';

$keyword = $_GET['keyword'];
$query_cari = "SELECT * FROM film WHERE
				judul LIKE '%$keyword%'
				";
$film = query($query_cari);
 ?>

 		 <?php foreach ($film as $f) : ?>
    <div class="card kartu" style="width: 25rem;">
      <div class="gm" style="background-image: url(assets/img/hh.jpeg);background-size:auto;">
      <img src="assets/img/<?= $f['poster']; ?>" class="card-img-top" alt="...">
      </div>
      <div class="card-body">
        <h5 class="card-title" align="center"><?= $f['judul']; ?> (<?= $f['tahun']; ?>)</h5>
        <a href="detail.php?no=<?= $f['no']; ?>" class="btn btn-primary tb">Go Detail</a>
      </div>
    </div>

    <?php endforeach ?>