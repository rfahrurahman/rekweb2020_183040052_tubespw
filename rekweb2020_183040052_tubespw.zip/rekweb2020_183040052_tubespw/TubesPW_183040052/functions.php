<?php 	
$conn = mysqli_connect('localhost', 'root', '', '183040052') or die("Koneksi ke DB gagal");;

function query($query){
	global $conn;
	$result = mysqli_query($conn, $query);

	$rows = [];
	while ($row = mysqli_fetch_assoc($result)) {
		$rows[] = $row;
	}
	return $rows;
}

function tambah($data){
	global $conn;
	$judul = htmlspecialchars($data['judul']);
	$tahun = htmlspecialchars($data['tahun']);
	$distribusi = htmlspecialchars($data['distribusi']);
	$durasi = htmlspecialchars($data['durasi']);
	$sinopsis = htmlspecialchars($data['sinopsis']);
	
	// Upload gambar
	$poster = upload();
	if (!$poster) {
		return false; 
	}

	$query = "INSERT INTO film 
			VALUES
			('', '$poster', '$judul', '$tahun', '$distribusi', '$durasi', '$sinopsis'  )";
		
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function upload(){

	$namaFile = $_FILES['poster']['name'];
	$sizeFile = $_FILES['poster']['size'];
	$error = $_FILES['poster']['error'];
	$tmpName = $_FILES['poster']['tmp_name'];

	//cek apakah tidak ada gambar yang diupload
	if ($error == 4) {
		echo "<script>
				alert('pilih gambar terlebih dahulu!');
				</script>";
		return false;
	}
	//cek apakah yang diupload adalah gambar
	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
		echo "<script>
				alert('yang anda upload bukan gambar!');
				</script>";
		return false;
	}

	// cek ukuran maksimal
	if ($sizeFile > 1000000 ) {
		echo "<script>
				alert('ukuran gambar terlalu besar!');
				</script>";
		return false;
	}

	//lolos pengecekan
	//generate nama gambar baru
	$namaFileBaru = uniqid();
	$namaFileBaru .= '.';
	$namaFileBaru .= $ekstensiGambar;

	move_uploaded_file($tmpName, 'assets/img/' . $namaFileBaru);

	return $namaFileBaru;





}

function hapus($no){
	global $conn;
	mysqli_query($conn, "DELETE FROM film WHERE no = $no");

	return mysqli_affected_rows($conn);
}

function ubah($data){
	global $conn;
	$no = $data['no'];
	$judul = htmlspecialchars($data['judul']);
	$tahun = htmlspecialchars($data['tahun']);
	$distribusi = htmlspecialchars($data['distribusi']);
	$durasi = htmlspecialchars($data['durasi']);
	$sinopsis = htmlspecialchars($data['sinopsis']);
	$poster = htmlspecialchars($data['poster']);
	$gambarLama = htmlspecialchars($data['gambarLama']);

	if ($_FILES['poster']['error'] === 4) {
		$poster = $gambarLama; 
	} else {
		$poster = upload();
	}
	$query = "UPDATE film 
				SET
				judul = '$judul',
				tahun = '$tahun',
				distribusi = '$distribusi',
				durasi = '$durasi',
				sinopsis = '$sinopsis',
				poster = '$poster'
			WHERE no = $no
				";
		
	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function registrasi($data) {
	global $conn;
	$username = strtolower(stripslashes($data["username"]));
	$password1 = mysqli_real_escape_string($conn, $data["password1"]);
	$password2 = mysqli_real_escape_string($conn, $data["password2"]);

	//cek user
	$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");
	if (mysqli_num_rows($cek_user) < 1) {
		// ok, cek password
		if ($password1 == $password2) {
			//ok, insert data ke database
			$password1 = password_hash($password1, PASSWORD_DEFAULT);
			$query = "INSERT INTO user VALUES
						('', '$username', '$password1')";
			mysqli_query($conn, $query);

			return mysqli_affected_rows($conn);

		} else {
			// password tidak sama
			echo "<script>
					alert('Konfirmasi Password Tidak Sesuai!');
					document.location.href = 'signup.php';
				</script>";
				return false;
		}

	} else {
		// gagal, username sudah terdaftar
		echo "<script>
				alert('Username sudah terdaftar!');
				document.location.href = 'signup.php';
				</script>
			"; 
			return false;
	}
}

 ?>