-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19 Sep 2020 pada 15.39
-- Versi Server: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw_183040052`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `film`
--

CREATE TABLE `film` (
  `no` int(11) NOT NULL,
  `poster_film` varchar(16) NOT NULL,
  `judul_film` varchar(64) NOT NULL,
  `tahun_rilis` varchar(64) NOT NULL,
  `negara_asal` varchar(64) NOT NULL,
  `durasi_film` varchar(64) NOT NULL,
  `distributor` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `film`
--

INSERT INTO `film` (`no`, `poster_film`, `judul_film`, `tahun_rilis`, `negara_asal`, `durasi_film`, `distributor`) VALUES
(1, 'ff8.jpg', 'FAST AND FORIOUS 8', '2017', 'Amerika Serikat', '2 jam 16 menit', 'Universal Studios'),
(2, 'do.jpg', 'DREADOUT', '2019', 'Indonesia', '1 jam 40 menit', 'GoodHouse Production'),
(3, 'm22.jpg', 'MILE 22', '2018', 'Amerika Serikat', '1 jam 40 menit', 'STXfilms'),
(4, 'aiw.jpg', 'AVENGERS: INFINITY WAR', '2018', 'Amerika Serikat', '2 jam 30 menit', 'Walt Disney Studios'),
(5, 'msb.jpg', 'MY STUPID BOSS', '2016', 'Indonesia', '1 jam 50 menit', 'Falcon Pictures'),
(6, 'bp.jpg', 'BLACK PANTHER', '2018', 'Amerika Serikat', '2 jam 15 menit', 'Walt Disney Studios'),
(7, 'cts.jpg', 'CEK TOKO SEBELAH', '2016', 'Indonesia', '1 jam 40 menit', 'PT. Kharisma Starvision Plus'),
(8, 'shc.jpg', 'SPIDERMAN: HOMECOMING', '2017', 'Amerikat Serikat', '2 jam 20 menit', 'Sony Pictures'),
(9, 'im3.jpg', 'IRON MAN 3', '2013', 'Amerikat Serikat', '2 jam 10 menit', 'Walt Disney Studios'),
(10, 'c2.jpg', 'CONJURING 2', '2016', 'Amerika Serikat', '2 jam 20 menit', 'Warner Bros. Pictures');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `film`
--
ALTER TABLE `film`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `film`
--
ALTER TABLE `film`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
